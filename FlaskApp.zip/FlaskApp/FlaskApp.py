from flask import Flask,render_template,request

application = Flask(__name__)

@application.route('/')
def helloworld():

    return render_template('list.html')

#@application is called decorator
@application.route('/search/seatlayout/<operatorID>/<DateOFtravel>')
def redbusToMorningStar(operatorID,DateOFtravel):

    print(operatorID,DateOFtravel)
    return "Ticket got booked"

@application.route('/query')
def queryParams():
    #print(request.args)
    for key,value in request.args.items():
        print(key,">>",value)
    return " NO Query params"

if __name__=='__main__':
    application.run(port=8080)