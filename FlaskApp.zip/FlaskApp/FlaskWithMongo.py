from flask import Flask, render_template, jsonify, request
from pymongo import MongoClient
import logging
import pdb
import json
from bson import ObjectId

logging.getLogger().setLevel(logging.INFO)
application = Flask(__name__)
client = MongoClient('localhost:27017')
db = client.assignment


@application.route('/')
def showMachineList():
    return render_template('list.html')


@application.route("/addStudent", methods=['POST'])
def addStudent():
    try:
        json_data = request.form
        logging.info(json_data)
        logging.info(json_data)
        name = json_data['name']
        email = json_data['email']
        age = json_data['age']

        db.student.insert_one({
            'name': name, 'email': email, 'age': age
        })
        return jsonify(status='OK', message='inserted successfully')

    except Exception:
        return jsonify(status='ERROR')


@application.route("/getStudentList", methods=['POST'])
def getStudentList():
    try:
        students = db.student.find()

        studentList = []
        for student in students:
            print
            student
            studentItem = {
                'name': student['name'],
                'email': student['email'],
                'age': student['age'],

                'id': str(student['_id'])
            }
            studentList.append(studentItem)
            print(studentList)
    except Exception:
        return Exception
    return json.dumps(studentList)


@application.route('/updateStudent', methods=['POST'])
def updateStudent():
    try:
        json_data = request.form
        name = json_data['name']
        email = json_data['email']
        age = json_data['age']
        id = json_data['id']

        db.student.update_one({'_id': ObjectId(id)}, {'$set': {'name': name, 'email': email, 'age': age}})
        return jsonify(status='OK', message='updated successfully')
    except Exception:
        return jsonify(status='ERROR')


@application.route("/deleteStudent", methods=['POST'])
def deleteStudent():
    try:
        logging.info(request)
        json_data = request.form
        ID = json_data['id']
        logging.info(">>>>" + ID + ">>")

        db.student.remove({'_id': ObjectId(ID)})
        return jsonify(status='OK', message='deletion successful')
    except Exception:
        return jsonify(status='ERROR')


if __name__ == "__main__":
    application.run()